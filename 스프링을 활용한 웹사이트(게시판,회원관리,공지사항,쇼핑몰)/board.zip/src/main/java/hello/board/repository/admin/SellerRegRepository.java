package hello.board.repository.admin;

import org.springframework.data.jpa.repository.JpaRepository;

import hello.board.domain.SellerReg;

public interface SellerRegRepository extends JpaRepository<SellerReg, Long>{

}
