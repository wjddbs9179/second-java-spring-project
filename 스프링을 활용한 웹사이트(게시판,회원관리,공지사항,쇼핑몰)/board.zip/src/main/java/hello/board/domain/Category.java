package hello.board.domain;

public enum Category {
	BOOK,
	CLOTH,
	FOOD
}
